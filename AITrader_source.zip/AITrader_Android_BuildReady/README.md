# AI Trader Android
مشروع Android Studio حقيقي مبني بـ Kotlin + Jetpack Compose.
افتح المجلد في Android Studio ثم انتظر Gradle Sync، وبعدها:
Build > Build APK(s)

النسخة الحالية واجهة MVP ولا تتصل بسوق حقيقي ولا تنفذ أوامر تداول.
