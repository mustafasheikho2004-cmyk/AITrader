package com.aitrader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Signal(val symbol:String,val score:Int,val trend:String,val reason:String)

class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{AITraderApp()}}
}

@Composable fun AITraderApp(){
 val bg=Color(0xFF071018); val card=Color(0xFF0D1B24); val green=Color(0xFF36E0A1)
 var capital by remember{mutableStateOf("10000")}
 var risk by remember{mutableStateOf("1")}
 var refreshed by remember{mutableStateOf(0)}
 val signals=listOf(
  Signal("BTC / USDT",86,"صاعد","اختراق مقاومة + زخم قوي"),
  Signal("ETH / USDT",68,"مراقبة","زخم إيجابي ويحتاج تأكيد"),
  Signal("SOL / USDT",79,"صاعد","حجم تداول متزايد")
 )
 MaterialTheme(colorScheme=darkColorScheme(background=bg,surface=card,primary=green)){
  Surface(modifier=Modifier.fillMaxSize(),color=bg){
   LazyColumn(modifier=Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
    item{
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
      Column{Text("AI TRADER",color=green,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("مساعد التداول الذكي",color=Color(0xFF9BB0BA),fontSize=12.sp)}
      Text("● متصل",color=green,fontSize=12.sp)
     }
    }
    item{
     Card(colors=CardDefaults.cardColors(containerColor=card),shape=RoundedCornerShape(18.dp)){
      Column(Modifier.padding(20.dp)){
       Text("قرارات أذكى، قبل الصفقة.",fontSize=28.sp,fontWeight=FontWeight.Bold)
       Spacer(Modifier.height(8.dp));Text("تحليل الاتجاه والزخم والمخاطر في لوحة واحدة.",color=Color(0xFF9BB0BA))
       Spacer(Modifier.height(15.dp));Button(onClick={refreshed++},colors=ButtonDefaults.buttonColors(containerColor=green,contentColor=Color.Black)){Text("تحديث التحليل")}
      }
     }
    }
    item{
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
      Stat("قوة السوق","72%","صاعد",green,card,Modifier.weight(1f))
      Stat("الإشارات","8","3 قوية",green,card,Modifier.weight(1f))
      Stat("المخاطرة","1.4%","منخفضة",green,card,Modifier.weight(1f))
     }
    }
    item{Text("الإشارات الذكية",fontSize=20.sp,fontWeight=FontWeight.Bold)}
    items(signals){s->SignalCard(s,green,card)}
    item{
     Card(colors=CardDefaults.cardColors(containerColor=card),shape=RoundedCornerShape(16.dp)){
      Column(Modifier.padding(18.dp)){
       Text("إدارة المخاطر",fontSize=20.sp,fontWeight=FontWeight.Bold)
       OutlinedTextField(value=capital,onValueChange={capital=it},label={Text("رأس المال")},modifier=Modifier.fillMaxWidth())
       Spacer(Modifier.height(10.dp))
       OutlinedTextField(value=risk,onValueChange={risk=it},label={Text("المخاطرة لكل صفقة %")},modifier=Modifier.fillMaxWidth())
       Spacer(Modifier.height(12.dp))
       val c=capital.toDoubleOrNull()?:0.0; val r=risk.toDoubleOrNull()?:0.0
       Text("الحد الأقصى للمخاطرة: ${"%.2f".format(c*r/100)}",color=green,fontWeight=FontWeight.Bold)
      }
     }
    }
    item{
     Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF241D0D)),shape=RoundedCornerShape(14.dp)){
      Text("⚠️ الإشارات تجريبية. لا تعتبر توقعًا مضمونًا للربح، ولا تنفذ صفقات حقيقية تلقائيًا.",Modifier.padding(16.dp),color=Color(0xFFE6C77B))
     }
    }
   }
  }
 }
}

@Composable fun Stat(title:String,value:String,sub:String,green:Color,card:Color,modifier:Modifier){
 Card(modifier=modifier,colors=CardDefaults.cardColors(containerColor=card),shape=RoundedCornerShape(14.dp)){
  Column(Modifier.padding(12.dp)){Text(title,color=Color(0xFF8FA6B0),fontSize=11.sp);Text(value,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(sub,color=green,fontSize=11.sp)}
 }
}
@Composable fun SignalCard(s:Signal,green:Color,card:Color){
 Card(colors=CardDefaults.cardColors(containerColor=card),shape=RoundedCornerShape(14.dp)){
  Row(Modifier.fillMaxWidth().padding(17.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
   Column(Modifier.weight(1f)){Text(s.symbol,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(s.reason,color=Color(0xFF839BA5),fontSize=12.sp);Text(s.trend,color=green,fontSize=12.sp)}
   Text("${s.score}%",color=green,fontWeight=FontWeight.Bold,fontSize=18.sp)
  }
 }
}
